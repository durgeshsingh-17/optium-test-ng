import { Injectable } from '@angular/core';
import { HttpMethods } from './httpmethods.service';
import { HttpUrlService } from './url.service';

@Injectable({ providedIn: 'root' })

export class HttpService {

    constructor(
        private url: HttpUrlService, 
        private HttpMethod: HttpMethods
    ) { }
    
    loginMethod(formData: object) {
        console.log(formData)
        console.log(this.url.login)
        return this.HttpMethod.postMethod(formData, this.url.login)
    }
}



