import { environment } from "src/environments/environment";
import { Injectable } from "@angular/core";

@Injectable({providedIn:'root'})

export class HttpUrlService {
    baseUrl: string = environment.baseUrl;
    login: string = this.baseUrl
}