import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class HttpMethods {
  httpOptions: Object = {};
  createHeader() {
    let token = localStorage.getItem('rec');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Token ' + token,
    });
  }
  
  createHeaderFormData() {
    // this.records = JSON.parse(localStorage.getItem('records'));
    let token = localStorage.getItem('rec');
    return new HttpHeaders({
      Authorization: 'Token' + ' ' + token,
    });
  }

  constructor(private http: HttpClient) {}

  //POST method which doesn't require token
  postMethod(postData: object, url: string) {
    return this.http.post(url, postData);
  }


  //POST method which requires Token
  postMethodWithAuth(postData: object, url: string) {
    console.log(url, postData)
    return this.http.post(url, postData, {
      headers: this.createHeader(),
    });
  }


  postMethodFormData(url: string, data: any) {
    return this.http.post(url, data, {
      headers: this.createHeaderFormData(),
    });
  }


  postNutritionix(url: string, data: any) {
    return this.http.post(url, data, {
      headers: {
        'x-app-id': 'b771b47a',
        'x-app-key': '653e2542936c3b6882b881385471643c',
        'Content-Type': 'application/json',
      },
    });
  }
}
