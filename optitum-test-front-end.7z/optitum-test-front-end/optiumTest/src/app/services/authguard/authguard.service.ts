import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()
export class AuthGuardServiceLogin implements CanActivate {
  constructor(public router: Router) {}
  canActivate(): boolean {
    var self = this;
    let rec = localStorage.getItem('rec');
    if (rec) {
      self.router.navigate(['admin']);
      return false;
    }
    return true;
  }
}
@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(public router: Router) {}
  canActivate(): boolean {
    var self = this;
    let rec = localStorage.getItem('rec');
    if (!rec) {
      self.router.navigate(['login']);
      return false;
    } else {
      return true;
    }
  }
}
