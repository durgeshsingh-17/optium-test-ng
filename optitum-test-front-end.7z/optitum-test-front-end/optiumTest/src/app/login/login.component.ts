import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from '../services/authguard/api.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  hide = true;

  constructor(
    private fb: FormBuilder,
    private http: HttpService,
    private router: Router,    
  ) { }

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
    password: ['', Validators.required]
  });

  userLogin() {
    console.log(this.loginForm.valid)
    console.log(this.loginForm.value)
    this.http.loginMethod(this.loginForm.value).subscribe((success)=> {
      console.log(success)
      this.router.navigate(['admin']);
    }, (err: Error) => {
      alert(err.message)
    })
  }

  ngOnInit(): void {
    
  }
}
