import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService, AuthGuardServiceLogin } from './services/authguard/authguard.service';

const routes: Routes = [
  {  path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', canActivate: [AuthGuardServiceLogin], loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path:'admin',canActivate:[AuthGuardService], loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
